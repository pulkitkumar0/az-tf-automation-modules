This example tests the creation of a new kv dynamic secret with a dynamic value.
useful case to deploy SQL server or VM with a dynamic password that created and pushed to the kV instead of writing a plain text password in the configuration file.
