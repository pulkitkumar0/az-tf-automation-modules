## v2.0 (March 2020)

FEATURES: 
* **new feature:**  Add support for azurerm 2.x and azurecaf providers ([#3](https://github.com/aztfmod/terraform-azurerm-caf-site-recovery/issues/3))


## v1.0 (January 2020)

FEATURES: 
* **new feature:**  Add support for naming convention ([#5](https://github.com/aztfmod/terraform-azurerm-caf-site-recovery/issues/5))
* **new feature:**  Add examples ([#4](https://github.com/aztfmod/terraform-azurerm-caf-site-recovery/issues/4))

IMPROVEMENTS:

BUGS:
* **bug fix:** Support for eventhub diagnostics is now optionnal ([#6](https://github.com/aztfmod/terraform-azurerm-caf-site-recovery/issues/6)) 